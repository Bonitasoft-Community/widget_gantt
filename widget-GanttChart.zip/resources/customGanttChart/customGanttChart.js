(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customGanttChart', function() {
    return {
      controllerAs: 'ctrl',
      controller: /**
 * The controller is a JavaScript function that augments the AngularJS scope and exposes functions that can be used in the custom widget template
 * 
 * Custom widget properties defined on the right can be used as variables in a controller with $scope.properties
 * To use AngularJS standard services, you must declare them in the main function arguments.
 * 
 * You can leave the controller empty if you do not need it.
 */
function ($scope) {
        var mode = 'Day';
        $scope.mode = mode;
        //$scope.$watch('properties.Mode', updateMode);
        $scope.$watch('properties.Mode', updateMode);
		var names = [
			["Redesign website", [0, 7]],
			["Write new content", [1, 4]],
			["Apply new styles", [3, 6]],
			["Review", [7, 7]],
			["Deploy", [8, 9]],
			["Go Live!", [10, 10]]
		];

		var tasks = names.map(function(name, i) {
			var today = new Date();
			var start = new Date(today.getFullYear(), today.getMonth(), today.getDate());
			var end = new Date(today.getFullYear(), today.getMonth(), today.getDate());
			start.setDate(today.getDate() + name[1][0]);
			end.setDate(today.getDate() + name[1][1]);
			return {
				start: start,
				end: end,
				name: name[0],
				id: "Task " + i,
				progress: parseInt(Math.random() * 100, 10)
			}
		});
		tasks[1].progress = 0;
		tasks[1].dependencies = "Task 0"
		tasks[2].dependencies = "Task 1"
		tasks[3].dependencies = "Task 2"
		tasks[5].dependencies = "Task 4"
		tasks[5].custom_class = "bar-milestone";

		var gantt_chart = Gantt("#gantt", tasks, {
			on_click: function (task) {
				console.log(task);
			},
			on_date_change: function(task, start, end) {
				console.log(task, start, end);
			},
			on_progress_change: function(task, progress) {
				console.log(task, progress);
			},
			on_view_change: function(mode) {
				console.log("Mode is "+$scope.properties.Mode);
			}
		});
		console.log(gantt_chart);
		
		function updateMode(){ 
		    
		    var gantt_chart = Gantt("#gantt", tasks, {
			on_click: function (task) {
				console.log(task);
			},
			on_date_change: function(task, start, end) {
				console.log(task, start, end);
			},
			on_progress_change: function(task, progress) {
				console.log(task, progress);
			},
			on_view_change: function(mode) {
				console.log("Mode is "+$scope.properties.Mode);
			}
		    });
		    gantt_chart.change_view_mode($scope.properties.Mode);
		    console.log("Mode!! "+ $scope.properties.Mode);
		}
},
      template: '<!-- The custom widget template is defined here\n   - You can use standard HTML tags and AngularJS built-in directives, scope and interpolation system\n   - Custom widget properties defined on the right can be used as variables in a templates with properties.newProperty\n   - Functions exposed in the controller can be used with ctrl.newFunction()\n   - You can use the \'environment\' property injected in the scope when inside the Editor whiteboard. It allows to define a mockup\n     of the Custom Widget to be displayed in the whiteboard only. By default the widget is represented by an auto-generated icon\n     and its name (See the <span> below).\n-->\n \n<span ng-if="environment"><identicon name="{{environment.component.id}}" size="30" background-color="[255,255,255, 0]" foreground-color="[51,51,51]"></identicon> {{environment.component.name}}</span>\n\n	<style>\n		body {\n			font-family: sans-serif;\n		}\n		.container {\n			width: 80%;\n			margin: 1 auto;\n		}\n		.gantt-container {\n			overflow: scroll;\n		}\n		/* custom class */\n		.gantt .bar-milestone .bar-progress {\n			fill: tomato;\n		}\n	</style>\n	\n	<div class="gantt-container">\n		<svg id="gantt" width="400" height="600"></svg>\n	</div>\n'
    };
  });
